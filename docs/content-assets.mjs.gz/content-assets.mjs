
import __ASTRO_IMAGE_IMPORT_188Kij from "../../../public/assets/images/brand/letter_logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Fdocs.mdx";
export default new Map([["../../../public/assets/images/brand/letter_logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Fdocs.mdx", __ASTRO_IMAGE_IMPORT_188Kij]]);
		