function n(c){return((c*=2)<=1?c*c*c:(c-=2)*c*c+2)/2}export{n as c};
